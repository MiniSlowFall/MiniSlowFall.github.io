const canvas = document.createElement("canvas");
const ctx = canvas.getContext("2d");
document.body.appendChild(canvas);
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// function resizeCanvas() {
//   //fit canvas to window and fix issues with canvas blur on zoom
//The crossed//symptoms
//   canvas.style.width = window.innerWidth + "px";
//   canvas.style.height = window.innerHeight + "px";
//   const scale = window.devicePixelRatio;
//   canvas.width = window.innerWidth * scale;
//   canvas.height = window.innerHeight * scale;
//   ctx.scale(scale, scale);
// }
// resizeCanvas();
// window.addEventListener("resize", resizeCanvas);

//canvas commands  https://www.w3schools.com/tags/ref_canvas.asp
//example drawings

function DrawBackground() {
  //Fat
  ctx.beginPath();
  ctx.ellipse(350, 225, 85, 100, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#8a2026";
  ctx.fill();
  ctx.stroke();
  //erenjeagerHead
  ctx.beginPath();
  ctx.arc(350, 100, 60, Math.PI * 2, 0);
  ctx.fillStyle = "#cf303a";
  ctx.fill();
  ctx.stroke();
  //Eye1
  ctx.beginPath();
  ctx.arc(325, 80, 10, Math.PI * 2, 0);
  ctx.fillStyle = "White";
  ctx.fill();
  ctx.stroke();
  //Pupil1
  ctx.beginPath();
  ctx.arc(325, 80, 3, Math.PI * 2, 0);
  ctx.fillStyle = "Black";
  ctx.fill();
  ctx.stroke();
  //Eye2
  ctx.beginPath();
  ctx.arc(375, 80, 10, Math.PI * 2, 0);
  ctx.fillStyle = "White";
  ctx.fill();
  ctx.stroke();
  //Pupil2
  ctx.beginPath();
  ctx.arc(375, 80, 3, Math.PI * 2, 0);
  ctx.fillStyle = "Black";
  ctx.fill();
  ctx.stroke();
  //Mouth
  ctx.beginPath();
  ctx.ellipse(350, 125, 25, 15, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#571217";
  ctx.fill();
  ctx.stroke();

  //Hills
  ctx.beginPath();
  ctx.arc(154, 400, 200, Math.PI, 0);
  ctx.fillStyle = "#43542d";
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(840, 370, 200, Math.PI, 0);
  ctx.fillStyle = "#47592e";
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(500, 380, 200, Math.PI, 0);
  ctx.fillStyle = "#2e470e";
  ctx.fill();
  ctx.stroke();

  //FOREGROUND BRIDGE
  //lines
  ctx.beginPath();
  ctx.moveTo(1030, 340);
  ctx.lineTo(1, 365);
  ctx.lineTo(1, 410);
  ctx.lineTo(1030, 375);
  ctx.lineTo(1030, 340);
  ctx.fillStyle = "Grey";
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(1030, 375);
  ctx.lineTo(1, 410);
  ctx.lineTo(1, 420);
  ctx.lineTo(1030, 385);
  ctx.lineTo(1030, 375);
  ctx.fillStyle = "#4c4d4c";
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(1030, 385);
  ctx.lineTo(1, 420);
  ctx.lineTo(1, 1000);
  ctx.lineTo(1030, 1000);
  ctx.lineTo(1030, 420);
  ctx.fillStyle = "#444544";
  ctx.fill();
  ctx.stroke();

  //bottompartition
  ctx.beginPath();
  ctx.moveTo(250, 1000);
  ctx.lineTo(245, 380);
  ctx.lineTo(350, 378);
  ctx.lineTo(360, 1000);
  ctx.fillStyle = "#50524f";
  ctx.fill();
  ctx.stroke();

  //toppartition
  ctx.beginPath();
  ctx.moveTo(245, 380);
  ctx.lineTo(250, 350);
  ctx.lineTo(340, 348);
  ctx.lineTo(350, 378);
  ctx.fillStyle = "Grey";
  ctx.fill();
  ctx.stroke();
  //Atmoshere
  const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
  gradient.addColorStop(0, "rgba(0, 0, 255, 0.4)");
  gradient.addColorStop(1, "rgba(31, 153, 149, 0)");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}

let birds = [
  { x: 700, y: 100, speed: 2, rise: 0.2, sink: 0.2, direction: "up" },
  { x: 500, y: 200, speed: 2.5, rise: 0.25, sink: 0.25, direction: "up" },
  { x: 300, y: 150, speed: 3, rise: 0.3, sink: 0.3, direction: "up" },
  { x: 800, y: 50, speed: 1.5, rise: 0.15, sink: 0.15, direction: "up" },
  { x: 600, y: 250, speed: 2.2, rise: 0.22, sink: 0.22, direction: "up" },
  { x: 400, y: 300, speed: 2.8, rise: 0.28, sink: 0.28, direction: "up" }
];

let sun = [{ x: 800, y: 50, speed: 0.25 }];

function drawSun(x, y) {
  ctx.beginPath();
  ctx.arc(x, y, 40, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(255, 204, 0, 1)";
  ctx.fill();
  ctx.stroke();
}

function drawBird(x, y) {
  //BirdBody
  ctx.beginPath();
  ctx.ellipse(x, y, 15, 10, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#333232";
  ctx.fill();
  ctx.stroke();

  //BirdHead
  ctx.beginPath();
  ctx.arc(x - 15, y, 6, 0, Math.PI * 2);
  ctx.fillStyle = "#333232";
  ctx.fill();
  ctx.stroke();

  //BirdEye
  ctx.beginPath();
  ctx.arc(x - 15, y - 2, 2, 0, Math.PI * 2);
  ctx.fillStyle = "#fff";
  ctx.fill();
  ctx.stroke();

  //BirdBeak
  ctx.beginPath();
  ctx.moveTo(x - 28, y);
  ctx.lineTo(x - 20, y - 3);
  ctx.lineTo(x - 20, y + 3);
  ctx.closePath();
  ctx.fillStyle = "#FFA500";
  ctx.fill();
  ctx.stroke();

  //BirdWing
  ctx.beginPath();
  ctx.moveTo(x + 27.5, y - 7);
  ctx.bezierCurveTo(x - 17.5, y + 15, x - 17.5, y - 5, x - 2.5, y - 5);
  ctx.lineTo(x + 12.5, y - 7);
  ctx.fillStyle = "#424242";
  ctx.fill();
  ctx.stroke();
}

//UpAndDownBirds
function changeBirdDirections() {
  birds.forEach((bird) => {
    //DirectionsForUpAndDown
    bird.direction = Math.random() < 0.5 ? "up" : "down";
  });
}
//ChangeDirectionsTimes
setInterval(changeBirdDirections, 2000);
//Animations
function cycle() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  sun.forEach((sun) => {
    sun.x -= sun.speed;
    if (sun.x < -50) {
      sun.x = canvas.width + 50;
    }
    drawSun(sun.x, sun.y);
  });
  DrawBackground();
  birds.forEach((bird) => {
    if (bird.direction === "up") {
      bird.y -= bird.rise;
    } else {
      bird.y += bird.sink;
    }
    bird.x -= bird.speed;
    if (bird.x < -50) {
      bird.x = canvas.width + 50;
    }
    drawBird(bird.x, bird.y);
  });

  requestAnimationFrame(cycle);
}

requestAnimationFrame(cycle);